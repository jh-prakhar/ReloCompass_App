# Task Spec: Phase 2 — Post-Login Journey (AI Assistant + Jobs + Employer Portal)

## Goal
Make the post-login experience real. Replace "coming soon" placeholders with working features:
1. **AI Assistant page** (`/assistant.html`) — chat UI wired to the existing `/api/chat` RAG backend (multi-turn, session history, sources, quick-start prompts, guardrail notice).
2. **Live Jobs board** (`/jobs.html`) — fetch real jobs from `/api/jobs`, filters (search, location, visa-only, type), job detail modal, apply flow for students/job_seekers with cover letter, "My Applications" view.
3. **Employer Portal** (`/employers.html` + dashboard) — Post a Job form (employer-only), My Posted Jobs list, view applicants per job.
4. **Dashboard upgrades** — role-specific cards linking to the new pages (Assistant, Browse Jobs, My Applications for students/seekers; Post a Job, My Jobs for employers).

## Files to Create/Modify

### New
1. `docs/assistant.html` — AI chat page
2. `docs/js/assistant.js` — chat logic (send, history, suggestions, sources)
3. `docs/js/jobs.js` — jobs page logic (fetch, filter, render, apply, modal)
4. `docs/js/employers.js` — employer portal logic (post job form, my jobs, applicants)
5. `backend/tests/test_jobs_flow.py` — job lifecycle integration tests
6. `backend/tests/test_chat_flow.py` — chat endpoint tests (mocked LLM)

### Modified
7. `docs/jobs.html` — dynamic job container + filters + modal markup (keep static sample cards as fallback skeleton → replaced by JS render)
8. `docs/employers.html` — post-job form + my-jobs + applicants sections
9. `docs/dashboard.html` — role cards updated; "Post a Job" / "Browse Candidates" open real pages
10. `docs/js/auth.js` — add `requireRole(roles)` helper (redirect if role not allowed)
11. `docs/css/style.css` — chat UI styles, filter bar, modal, job cards, typing indicator
12. All pages' nav — add "AI Assistant" link
13. `backend/app/routers/jobs.py` — add `GET /jobs/mine` (employer's own jobs), `GET /jobs/{id}/applications` (employer's applicants for own job), `job_type` + `visa_sponsorship` + search filters on `GET /jobs`
14. `backend/app/routers/jobs.py` — add `DELETE /jobs/{id}` (employer deactivates own job) and `PATCH /jobs/applications/{application_id}` (employer updates application status: pending → reviewed → shortlisted → rejected → accepted)

## Acceptance Criteria

### AI Assistant
- [ ] `/assistant.html` reachable from navbar (all pages) and dashboard cards
- [ ] Chat sends message to `POST /api/chat`, renders reply
- [ ] Multi-turn: session_id reused; conversation persisted (reload restores history via `GET /api/chat/history/{session_id}`)
- [ ] Sources (knowledge-base citations) rendered when present
- [ ] Quick-start suggestion chips shown when conversation is empty (role-aware: student / job_seeker / employer variants)
- [ ] Guardrail notice displayed (AI guidance, not legal/immigration advice)
- [ ] Handles 503 (AI not configured) with friendly error
- [ ] Works for anonymous users (chat is optional-auth)

### Jobs
- [ ] Jobs page loads real jobs from `GET /api/jobs` (with filters: q search, location, job_type, visa-only)
- [ ] Empty state shown when no jobs match
- [ ] Clicking a job opens detail modal with full description
- [ ] Apply button (students/job_seekers, logged in) opens cover-letter textarea → `POST /api/jobs/{id}/apply` → success message
- [ ] Duplicate apply → 409 shown as friendly error
- [ ] Not-logged-in users see "Login to apply" prompt instead of apply button
- [ ] "My Applications" section lists applications with status badges
- [ ] Employers browsing jobs do NOT see Apply button (403 guard both UI + API)

### Employer Portal
- [ ] Post a Job form validates: title ≥3 chars, company ≥2 chars
- [ ] Employer-only: student/job_seeker attempting `POST /api/jobs` → 403
- [ ] Posted job appears in "My Posted Jobs" after submit
- [ ] Employer can view applicants for own job (name, email, cover letter, applied date)
- [ ] Employer cannot view applicants for another employer's job → 403
- [ ] Employer can update application status; job seeker sees updated status in My Applications
- [ ] Employer can delete (deactivate) own job; deleted jobs vanish from the board

### Dashboard
- [ ] Student cards: AI Assistant, Browse Jobs, My Applications
- [ ] Job seeker cards: AI Assistant, Browse Jobs, My Applications
- [ ] Employer cards: AI Assistant, Post a Job, My Posted Jobs

### Backend
- [ ] `GET /api/jobs` supports `q`, `location`, `job_type`, `visa_only` query params
- [ ] `GET /api/jobs/mine` returns employer's own jobs (auth required, employer only)
- [ ] `GET /api/jobs/{id}/applications` returns applicants (own job only)
- [ ] `PATCH /api/jobs/applications/{app_id}` updates status (employer owns the underlying job)
- [ ] `DELETE /api/jobs/{id}` soft-deletes (is_active=False) own job
- [ ] All new endpoints have integration tests, all pass

### Tests
- [ ] `test_jobs_flow.py`: filter combos, apply flow (201/409/403), employer lifecycle (create → mine → applicants → status update → delete)
- [ ] `test_chat_flow.py`: chat with mocked LLM returns reply+session_id; history persists; clear history works

## Edge Cases
- Job deleted after user opened modal → apply returns 404, friendly error
- Chat 503 → "AI is being configured" message
- Empty jobs result → helpful empty state
- Session expiry mid-flow → 401 → redirect to login
- Long chat histories render scrolled to bottom

## Out of Scope (later phases)
- Accommodation browse UI wiring
- Cost-of-living calculator
- Community hub
- CV builder
