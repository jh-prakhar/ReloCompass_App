# Task Spec: Phase 3 — Android App (Native Kotlin + Jetpack Compose) + PWA Install

## Goal
Deliver a native Android app for ReloCompass that consumes the live FastAPI backend
(`https://relocompass-tpfpaa.drytis.dev`), plus make the web frontend installable on
Android (PWA manifest + icons) as an instant-install option.

Two deliverables:
1. **Native Android app source** (Kotlin, Jetpack Compose, Material 3) — complete,
   buildable in Android Studio, targeting the live API. Lives in `android/` in the repo.
2. **PWA support** for the existing site — `manifest.webmanifest` + icons + install
   prompt affordances, so Android users can "Add to Home Screen" a full-screen app
   experience immediately while the native app is being built.

## Part 1 — Native Android App

### Architecture
- Single-module app: `app/` (Gradle Kotlin DSL)
- Kotlin 2.x, Jetpack Compose (BOM), Material 3, Navigation Compose
- Min SDK 26 (Android 8.0), Target/Compile SDK 35
- Networking: Retrofit + OkHttp + kotlinx.serialization
- State: ViewModel + StateFlow
- Token storage: EncryptedSharedPreferences? → plain SharedPreferences with
  private-mode (EncryptedSharedPreferences is deprecated path in newer security-crypto;
  use regular SharedPreferences private mode + note in README; no PII beyond email stored)
- API base URL: injected via `BuildConfig.API_BASE_URL` (default = live backend),
  overridable per build type (debug → 10.0.2.2:8000 for emulator against local backend)

### Screens (Nav graph)
1. **Splash / Auth gate** — if token exists → Dashboard, else → Login
2. **Login** — email + password, error display, "demo account" hint chips
   (student/employer), link to Register
3. **Register** — name, email, password, role selector (Student / Job Seeker / Employer)
4. **Dashboard** — role-aware welcome + quick-action cards:
   - Student/Job Seeker: AI Assistant, Browse Jobs, My Applications, Profile
   - Employer: AI Assistant, Post a Job, My Jobs, Profile
5. **AI Assistant (Chat)** — conversation list from history, send message,
   typing indicator, source chips per reply, "New conversation", disclaimer
6. **Jobs** — list with search bar + filters (job type chips, visa-only toggle),
   pull-to-refresh; tap → Job Detail
7. **Job Detail** — full description, meta, Apply (seekers) with cover letter
   dialog → success/error feedback; employers see "posted by employer" info
8. **My Applications** — list with status badges (color per status)
9. **Employer: Post Job** — form (title*, company*, location, type dropdown,
   experience dropdown, visa toggle, description)
10. **Employer: My Jobs** — posted jobs with applicant counts; tap → Applicants
11. **Employer: Applicants** — applicant cards (name/email/country/date/cover letter
    excerpt) + status dropdown (pending/reviewed/shortlisted/rejected/accepted)
12. **Profile** — view + edit (name, phone, country, city, bio) + logout

### Backend contract (all exist, JWT Bearer)
- POST /api/auth/register {name,email,password,role} → {access_token, user}
- POST /api/auth/login {email,password} → {access_token, user}
- GET /api/auth/verify | /api/users/me → UserOut
- PUT /api/users/me {name,phone,country,city,bio} → UserOut
- GET /api/jobs/?q=&location=&job_type=&visa_only=&skip=&limit= → [JobOut]
- GET /api/jobs/mine (employer) → [JobOut]
- GET /api/jobs/{id} → JobOut
- POST /api/jobs/ (employer) → JobOut
- DELETE /api/jobs/{id} (owner) → {message}
- POST /api/jobs/{id}/apply {cover_letter} → ApplicationOut
- GET /api/jobs/applications/me → [ApplicationOut]
- GET /api/jobs/{id}/applications (owner) → [{...applicant:{name,email,country}}]
- PATCH /api/jobs/applications/{id} {status} → ApplicationOut
- POST /api/chat/ {message,session_id,user_context} → {reply,session_id,sources,model_used}
- GET /api/chat/history/{session_id} → {messages:[{role,content}]}
- DELETE /api/chat/history/{session_id}

### Files (android/)
```
android/settings.gradle.kts
android/build.gradle.kts
android/gradle.properties
android/gradle/wrapper/gradle-wrapper.properties
android/app/build.gradle.kts
android/app/src/main/AndroidManifest.xml
android/app/src/main/res/values/strings.xml
android/app/src/main/res/values/themes.xml
android/app/src/main/res/xml/network_security_config.xml
android/app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml (adaptive icon)
android/app/src/main/res/drawable/ic_launcher_foreground.xml (vector compass)
android/app/src/main/res/values/ic_launcher_background.xml
android/app/src/main/res/xml/file_paths.xml (if needed)
android/app/src/main/java/ai/relocompass/app/
  MainActivity.kt
  ReloApp.kt (Application: OkHttp/Retrofit/DI-lite singletons)
  data/Api.kt (Retrofit interfaces + DTOs)
  data/Prefs.kt (token + user cache)
  data/Models.kt
  ui/theme/{Theme.kt,Color.kt,Type.kt}
  ui/AppNav.kt (NavHost + auth gate)
  ui/components/Common.kt (cards, badges, inputs, status colors, source chips)
  ui/screens/{Splash.kt,Login.kt,Register.kt,Dashboard.kt,Chat.kt,Jobs.kt,
              JobDetail.kt,Applications.kt,PostJob.kt,MyJobs.kt,Applicants.kt,Profile.kt}
android/README.md (build & run instructions, demo accounts, emulator backend URL note)
android/.gitignore
```

### Acceptance Criteria (Native)
- [ ] Project structure builds in Android Studio (Gradle sync + assembleDebug) —
      verified by the user in Android Studio (container has no SDK; code is written
      to standard templates, versions pinned, no experimental APIs)
- [ ] Login/Register work against the live API (verified via curl-contract parity;
      UI code paths mirror the verified web flows)
- [ ] Auth gate: token present → Dashboard; expired/invalid → Login
- [ ] All 12 screens present per spec, wired to the API contract above
- [ ] Role-gated UI: seekers can't see Post Job/My Jobs; employers can't Apply
- [ ] Chat screen: send/receive, typing indicator, sources, new conversation,
      history restore via GET history
- [ ] Jobs: search + type + visa filters functional
- [ ] Apply flow with cover letter + duplicate (409) handled gracefully
- [ ] Applicants: status updates via PATCH; errors shown
- [ ] Profile edit persists via PUT /users/me
- [ ] No hardcoded secrets; API base URL via BuildConfig; demo creds only in README
- [ ] README covers: Android Studio open → run, emulator local-backend override,
      release signing notes, demo accounts

### Tests
- Pure-Kotlin unit tests are limited without Gradle in this container; instead:
  - Contract parity tests: python script tests/android_contract_test.py that
    exercises every endpoint the app calls against the live API and asserts
    shapes (status codes + key fields) — run in CI/container
  - (Optional, documented) androidTest: MainActivity smoke test file included
    for the user to run in Studio

## Part 2 — PWA Install

### Files (web)
- `docs/manifest.webmanifest` (name, short_name, theme #0F172A, background,
  display standalone, icons 192/512, start_url ./index.html, scope ./)
- `docs/assets/icons/icon-192.png`, `icon-512.png` (compass mark, PIL-generated)
- Link tag added to all 9 HTML pages
- `docs/sw.js` — minimal service worker: network-first for navigation/API,
  cache-first for icons/fonts/static; registered in main.js (guarded)
- `docs/js/main.js` — register SW + beforeinstallprompt capture → install button
  in navbar (hidden until prompt available; iOS shows instructions alert)

### Acceptance Criteria (PWA)
- [ ] manifest served at /manifest.webmanifest (200) with valid JSON
- [ ] Icons 192 + 512 PNG served (200)
- [ ] All pages reference manifest + theme-color
- [ ] SW registers without errors; offline shows cached shell
- [ ] Lighthouse-style basics: icons match, maskable purpose set
- [ ] Install button appears on Chrome/Android when eligible
- [ ] App title/name correct in installed state (ReloCompass)

## Edge Cases
- API down / network error → friendly retry screens on every list screen
- 401 mid-session → clear token, navigate Login
- Chat 503 → "AI is being configured" message
- Duplicate apply 409 → friendly message
- Employer browsing jobs: no Apply button
- Empty states everywhere (jobs, applications, applicants, chat)
- Long text (cover letters, descriptions) truncated with expandable

## Out of Scope
- Push notifications
- Native offline database (Room) — server is source of truth
- Play Store release pipeline (documented in README only)
- iOS-specific PWA tweaks beyond standard meta tags
