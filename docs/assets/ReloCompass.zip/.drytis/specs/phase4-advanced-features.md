# Phase 4 — Advanced Features

Spec for 9 features: email notifications, job matching, multi-language, PWA
offline, community chat, visa checklist generator, university housing API,
SSE streaming AI, OCR ingestion.

## 1. Email notification system — DONE
- [x] `email_outbox` + `password_reset_tokens` tables (create_all)
- [x] `app/services/email.py`: SMTP send when configured, else dev outbox (log + DB row)
- [x] `POST /api/auth/password-reset` (JSON body) issues 30-min single-use token (sha256-hashed), emails reset link
- [x] `POST /api/auth/password-reset/confirm` sets new password, invalidates token
- [x] `docs/reset-password.html` page; "Forgot password?" from login (inline fetch)
- [x] Application status change (PATCH /jobs/applications/{id}) emails the applicant (background task)
- [x] `GET /api/admin/emails` (admin only) — outbox inspection
- [x] Env keys: SMTP_HOST/PORT/USER/PASSWORD/FROM, FRONTEND_URL
- [x] Tests: tests/test_password_reset.py (7 tests)

## 2. Advanced job matching — DONE
- [x] `app/services/matching.py`: skills dict (~40 patterns), score = skills 40% + location 25% + visa 20% + recency 15%
- [x] `GET /api/jobs/match?skills=&city=&country=&needs_visa=&min_score=&limit=` (auth; falls back to user profile fields)
- [x] Jobs page "✨ For You" section: top-4 matches with score badge + reason chips, click opens detail modal
- [x] Tests: tests/test_job_matching.py (5 tests)

## 3. Multi-language (en, hi, ne, es, fr) — DONE (nav + auth/reset strings)
- [x] `docs/js/i18n.js`: dictionary + I18N_UTIL.t/apply/setLang, data-i18n / data-i18n-placeholder attributes
- [x] Language picker in navbar (all pages), persisted in localStorage, ?lang= support, <html lang> update
- [x] Translated: nav links, login/forgot/reset flows (further page bodies fall back to English keys)
- [x] Node completeness check executed (all langs share the key set)

## 4. PWA offline — DONE
- [x] sw.js v3: precache pages incl. community/visa/reset/offline; offline.html fallback
- [x] Queue POST /api/jobs/{id}/apply when offline (cache-based store), replay on sync + 'online', message-based replay for Safari
- [x] jobs.js shows "Queued — will send on reconnect" on 202/X-Relocompass-Queued

## 5. Real-time community chat (global + topic rooms) — DONE
- [x] `community_messages` table; rooms: global, housing, visas, jobs
- [x] WebSocket `/api/community/ws?token=&room=` JWT auth (query param), last-50 history, presence broadcasts, rate limit 30/min, 1000-char cap
- [x] REST: `GET /api/community/rooms`, `GET /api/community/history/{room}` (public read)
- [x] `docs/community.html` + `js/community.js` + nav link on all pages; reconnect w/ exponential backoff; read-only mode when logged out
- [x] Tests: tests/test_community_chat.py (7 tests)

## 6. Visa & immigration checklist generator — DONE
- [x] `app/services/visa_checklist.py`: rule matrix — 5 destinations (ca/de/au/us/uk) × visa types × situations (student/job_seeker/family/with_kids), phased items + official sources + disclaimer
- [x] `GET /api/visa/destinations`, `GET /api/visa/checklist?destination=&visa_type=&situation=`
- [x] `docs/visa-checklist.html` + `js/visa.js`: cascading selects, phased checklist, localStorage checkbox persistence per combo, progress bar, print
- [x] Tests: tests/test_visa_checklist.py (9 tests)

## 7. University housing API (demo provider) — DONE
- [x] `app/services/university_housing.py`: HousingProvider protocol, DemoUniversityProvider (TU Berlin/LMU Munich/UofT), PROVIDERS registry
- [x] `GET /api/housing/providers`, `GET /api/housing/availability?university=&move_in=&max_monthly_cost=&kind=`
- [x] Tests: tests/test_housing_api.py (7 tests)

## 8. Streaming AI (SSE) — DONE
- [x] `POST /api/chat/stream`: SSE events meta → delta×N → done/error; history persisted in finally (own DB session) even on disconnect
- [x] assistant.js streams via fetch ReadableStream, renders progressively, falls back to non-streaming POST /chat/
- [x] Tests: tests/test_chat_stream.py (3 tests, live LLM)

## 9. Multi-modal ingestion (OCR via LLM vision) — DONE
- [x] `app/ai/ocr.py`: ocr_image (png/jpg/jpeg/webp, 8 MB cap) + ocr_scanned_pdf (page-image extraction, 10-page cap); vision model = drytis/kimi (the default chat model is text-only — probed live)
- [x] ingest_document routes images and textless PDFs through OCR; result includes ocr_used
- [x] Live probe: PIL-generated checklist image transcribed exactly
- [x] Tests: tests/test_ocr.py (4 tests)

## Verification (all features = major change → full path)
- [ ] Unit + integration tests green (114 passing at time of writing)
- [ ] Infrastructure gate: procmgr, env keys via backend, no dev processes, Caddy, preview 200
- [ ] infra_verifier PASS; reviewer PASS; tester browser PASS (per-feature scenarios)
- [ ] Publish only when user confirms
