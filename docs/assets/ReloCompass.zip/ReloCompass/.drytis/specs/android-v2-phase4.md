# Android App v2 — Phase 4 Features

Extend the existing native Android client (Kotlin + Compose) with the Phase 4
platform features. Same hosted backend, same architecture (Retrofit + OkHttp +
DataStore + Compose Material 3).

## Scope (6 deliverables)

1. **New API surface** (`ReloApi.kt` + DTOs in `Dto.kt`):
   - `GET jobs/match?limit=` → `MatchResponse(matches: List<JobMatch>, total_scored: Int)`;
     `JobMatch(job: Job, score: Int, reasons: List<String>, skills_matched: List<String>)`
   - `GET visa/destinations` → destinations catalogue (id, label, visa_types[], official_sources[])
   - `GET visa/checklist?destination=&visa_type=&situation=` → phased checklist
     (checklist: [{phase, label, items: [{id, label, phase, note}]}], total_items, official_sources, disclaimer)
   - `GET community/rooms` → rooms catalogue; `GET community/history/{room}` → persisted history
   - `GET housing/providers` + `GET housing/availability?university=` → dorm/studio options
   - `POST auth/password-reset` (email) — password-reset request from mobile
2. **JobsScreen "For You" section**: horizontally scrolling match cards at top
   (score badge, top reasons, matched skills chips), tap → existing job detail.
   Degrades to hidden when the match call fails or returns empty.
3. **VisaScreen**: destination selector → visa type → situation → phased checklist
   with checkboxes (local progress state), progress bar, official-source links,
   disclaimer footer. Phases collapsible; item notes shown as secondary text.
4. **CommunityScreen**: WebSocket chat (`/api/community/ws?token=&room=`) over
   OkHttp WebSocket — room switcher (4 rooms), persisted history on open
   (REST `GET community/history/{room}`), presence count, own vs others message
   styling, reconnection with backoff + stale-socket generation guard (the exact
   race fixed on web — do not reintroduce it), input disabled until OPEN.
5. **HousingScreen**: provider + university picker → availability list (kind chip,
   monthly cost + currency, available-from date, distance, meals, notes).
6. **Navigation**: new bottom-bar destinations for Visa + Community (5 visible +
   overflow or 6 destinations max per Material guidance), dashboard cards updated
   to deep-link into the new screens.

## Acceptance criteria (reviewer + contract test gate)

- [ ] All new Retrofit paths exactly match the live backend (pinned in
      `backend/tests/android_contract_test.py` — extend it with every new route).
- [ ] DTO fields match live response shapes (verified against captured JSON).
- [ ] Community WebSocket: switching rooms never delivers messages to the wrong
      room or reconnects to the old room (generation guard present in code).
- [ ] VisaScreen handles unknown destination/visa gracefully (404 → error snackbar).
- [ ] No hardcoded API URLs in Kotlin source (ApiClient baseUrl comes from
      BuildConfig only).
- [ ] Existing unit tests still pass; new DtoContract tests cover the new shapes.
- [ ] No secrets in source; strings not user-generated are safe to render.
- [ ] minSdk 24 / targetSdk 34 unchanged; no new dangerous permissions.
- [ ] README (root + android/) updated to describe v2 features.

## Verification

- Full path: contract test extension + `DtoContractTest`/`ErrorsTest` additions,
  reviewer pass on new Kotlin files, updated standalone Android zip rebuilt.
- Browser tester N/A (native app, no emulator in container) — contract tests +
  reviewer stand in; the web equivalents were browser-tested in Phase 4.
