# Phase 5 — Pages Fix + Post-Login Completion + Repository Cleanup

Continue from 4f93236. Do NOT rebuild. Same repo (jh-prakhar/ReloCompass_App), same
stack (HTML/CSS/vanilla JS + FastAPI + MySQL here / SQLite-PostgreSQL compatible).

## Root cause of "features missing after login" on GitHub Pages
`docs/js/config.js` BASE_URL resolves to `''` (same-origin) on github.io, so all
API calls 404 against jh-prakhar.github.io. Fix: add a GitHub Pages branch of the
resolver — when hostname ends with `github.io`, fall back to the hosted backend
`https://relocompass-tpfpaa.drytis.dev` (keeps localhost for dev, override
`localStorage.relo_backend_url` still wins). No hardcoded hosts for
localhost/same-origin deployments.

## Deliverables

### A. Backend (new endpoints, all JWT-protected unless noted)
1. `SavedJob` + `SavedAccommodation` models (`saved_jobs`, `saved_accommodations`
   tables: id, user_id FK, job_id/accommodation_id FK, created_at, unique
   constraint (user_id, job_id)); REST:
   - `POST /api/jobs/{id}/save` / `DELETE /api/jobs/{id}/save` (idempotent)
   - `GET /api/jobs/saved` → jobs + saved_at
   - `POST /api/accommodations/{id}/save` / `DELETE /api/accommodations/{id}/save`
   - `GET /api/accommodations/saved`
2. `RelocationPlan` model (id, user_id, destination_country, destination_city,
   move_date, notes, checklist_json TEXT, updated_at); REST:
   - `GET/PUT /api/planner` (single plan per user, upsert; 200 always for GET)
3. `Notification` model (id, user_id, kind, title, body, is_read, created_at);
   seed on application-status change (reuse existing email hook point); REST:
   - `GET /api/notifications` (limit 50), `POST /api/notifications/read-all`,
     `POST /api/notifications/{id}/read`
4. Settings: extend `PUT /api/users/me` with `preferred_language` column on User
   (default 'en') + include in UserOut/ProfileUpdate. Password change:
   `PUT /api/users/me/password` (current_password, new_password; verify + hash).
5. All new tables via `Base.metadata.create_all` (project pattern), seeded in the
   idempotent setup script where needed. Tests for every route above.
6. Demo admin seed stays `admin@relocompass.org / Admin@12345` (existing,
   DEV_ADMIN_* env-keyed, never in frontend; README documents dev-only status).

### B. Frontend
1. **config.js GitHub Pages resolver fix** (root cause above).
2. **Saved pages**: `saved.html` — two tabs (Jobs / Accommodation), unsave
   buttons, empty states ("No saved jobs yet").
3. **Planner**: `planner.html` + `js/planner.js` — destination, move date, notes,
   10-step starter checklist (transport, housing, bank, visa docs …) stored via
   PUT /api/planner, progress bar, autosave (debounced).
4. **Notifications**: bell icon in authenticated nav with unread count badge;
   dropdown lists notifications, mark-all-read; dashboard shows recent 5.
5. **Settings**: `settings.html` — language select (en/hi/ne/es/fr, reuses i18n),
   password change form.
6. **Dashboard**: add cards/links for Saved, Planner, Notifications, Settings;
   keep existing role-aware quick actions; no fake stats anywhere (empty states
   only). Nav (all authenticated pages): Dashboard, AI Assistant, Jobs,
   Accommodation, Community, Transportation (existing about/transport section),
   Planner, Saved, Profile, Settings, Logout.
7. Jobs board: Save/Unsave heart on cards + detail modal; "Saved" tab filter.
8. Accommodation page (`accommodations.html` NEW): list from
   GET /api/accommodations (filters: city, type, max price), Save/Unsave;
   **empty state "No verified accommodation listings are currently available."**
   when the API returns none — the 3 seeded rows are clearly labeled
   "Sample — demonstration data".
9. Transportation: `transport.html` NEW — curated static guidance cards
   (public transport passes, airport transfers, planning) with links to official
   providers (BVG, TfL, Translink, MVV); no fake data, "Coming soon" for other
   cities.
10. i18n: tag new pages with data-i18n for existing keys (nav + common); new keys
    added to all 5 locales.
11. All new pages: relative asset paths (work under /ReloCompass_App/), auth
    guard (redirect to login), language picker mount, PWA manifest metas.

### C. Repository cleanup
- Delete stray root artifacts: homepage.png, jobs-page-full.png, jobs-page.png,
  scenario1-assistant-anon.png (unused — verify no references first).
- `.gitignore`: add `*.log`, `backend/.pytest_cache/`, `docs/.playwright-mcp/`,
  `**/__pycache__/` already there — verify; add `relocompass-2*` etc.
- Remove `backend/.env.example` drift (sync entries with actual env keys — no secrets).
- Keep everything else; do NOT touch working code, android/, .drytis/, READMEs.

### D. Verification (full path)
- Unit + integration tests for every new endpoint (backend suite green).
- infra_verifier: env keys match, no hardcoded hosts in source (config.js Pages
  fallback is the documented exception), services running, preview reachable.
- reviewer: spec compliance + security on new code.
- tester (Playwright, preview URL): signup → login → dashboard; nav links;
  jobs save/unsave flow; saved page; planner save; notifications bell;
  settings language switch + password change (change back); accommodation page;
  transport page; logout redirects to public homepage; console error check.
- Then publish (same repo) and re-verify the DEPLOYED Pages site: login works,
  dashboard appears, API calls reach the backend (network tab via curl of
  config.js + live API smoke).

## Acceptance criteria
- [ ] Pages deployment: config.js resolves backend correctly for github.io host
- [ ] Login on Pages → dashboard renders, zero API 404s
- [ ] Saved jobs/accommodations persist per user (DB rows, reload survives)
- [ ] Planner upsert + read round-trips; checklist progress persists
- [ ] Notifications created on application status change; read-all works
- [ ] Password change requires current password; wrong → 400/401
- [ ] preferred_language round-trips through profile
- [ ] No fake stats/reviews anywhere; empty states where no data
- [ ] Sample accommodations labeled as demo
- [ ] Cleanup: no unused artifacts at repo root; .gitignore current
- [ ] Backend suite green incl. new tests; contract test 32/32
- [ ] Deployed Pages verification PASS
